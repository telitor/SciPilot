import { lazy, Suspense, useCallback, useState, useMemo, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BarChart3, TrendingUp, Download, FileSpreadsheet, Loader2, ArrowRight, FolderKanban, Plus, Trash2 } from 'lucide-react';
import AgentKnowledgePanel from '@/components/AgentKnowledgePanel';
import ArtifactReviewToolbar, { mergeArtifactDetail } from '@/components/ArtifactReviewToolbar';
import ProjectContextBar from '@/components/ProjectContextBar';
import { useDurableResearchJob } from '@/hooks/useDurableResearchJob';
import { artifactAPI, experimentRunAPI, resultAPI } from '@/services/api';
import { getApiErrorMessage } from '@/services/errors';
import { useAuthStore } from '@/store/authStore';
import { useSelectedProjectId } from '@/store/projectStore';
import { useUIStore } from '@/store/uiStore';
import type { ExperimentRun, ResultAnalysis } from '@/types';

const ResultChart = lazy(() => import('@/components/charts/ResultChart'));

function ResultAnalyze() {
  const selectedProjectId = useSelectedProjectId();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const linkedRepoId = searchParams.get('repoId');
  const linkedRunId = searchParams.get('runId');
  const userId = useAuthStore((state) => state.user?.id || 'anonymous');
  const storageKey = `scipilot-current-result-analysis:${userId}${selectedProjectId ? `:${selectedProjectId}` : ''}`;
  const sourceStorageKey = `${storageKey}:repo-id`;
  const runStorageKey = `${storageKey}:run-id`;
  const jobStorageKey = `${storageKey}:job-id`;
  const [file, setFile] = useState<File | null>(null);
  const [linkedRun, setLinkedRun] = useState<ExperimentRun | null>(null);
  const [selectedResultFileId, setSelectedResultFileId] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<import('@/types').ResultAnalysis | null>(null);
  const [draftAnalysis, setDraftAnalysis] = useState<ResultAnalysis | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { addNotification } = useUIStore();

  const handleJobSucceeded = useCallback((result: ResultAnalysis) => {
    setAnalysis(result);
    setDraftAnalysis(null);
    setIsEditing(false);
    if (result.id) {
      localStorage.setItem(storageKey, result.id);
      if (linkedRepoId) localStorage.setItem(sourceStorageKey, linkedRepoId);
      else localStorage.removeItem(sourceStorageKey);
      if (linkedRunId) localStorage.setItem(runStorageKey, linkedRunId);
      else localStorage.removeItem(runStorageKey);
    }
    addNotification({ type: 'success', message: '数据分析完成', duration: 3000 });
  }, [addNotification, linkedRepoId, linkedRunId, runStorageKey, sourceStorageKey, storageKey]);

  const handleJobFailed = useCallback((message: string) => {
    addNotification({ type: 'error', message, duration: 5000 });
  }, [addNotification]);

  const {
    job,
    isRunning: isJobRunning,
    track: trackJob,
    retry: retryJob,
    cancel: cancelJob,
  } = useDurableResearchJob<ResultAnalysis>({
    storageKey: jobStorageKey,
    jobType: 'result-analysis',
    projectId: selectedProjectId,
    onSucceeded: handleJobSucceeded,
    onFailed: handleJobFailed,
  });

  useEffect(() => {
    setAnalysis(null);
    const artifactId = localStorage.getItem(storageKey);
    const storedRepoId = localStorage.getItem(sourceStorageKey);
    const storedRunId = localStorage.getItem(runStorageKey);
    if (linkedRepoId && storedRepoId !== linkedRepoId) return;
    if (linkedRunId && storedRunId !== linkedRunId) return;
    if (!artifactId) return;
    resultAPI.getAnalysis(artifactId)
      .then((response) => setAnalysis(response.data))
      .catch(() => {
        localStorage.removeItem(storageKey);
        localStorage.removeItem(sourceStorageKey);
        localStorage.removeItem(runStorageKey);
      });
  }, [linkedRepoId, linkedRunId, runStorageKey, sourceStorageKey, storageKey]);

  useEffect(() => {
    setLinkedRun(null);
    setSelectedResultFileId('');
    if (!linkedRunId) return;
    experimentRunAPI.get(linkedRunId)
      .then((response) => {
        setLinkedRun(response.data);
        if (response.data.result_artifact_id) {
          return resultAPI.getAnalysis(response.data.result_artifact_id).then((artifactResponse) => {
            setAnalysis(artifactResponse.data);
            setDraftAnalysis(null);
            setIsEditing(false);
            localStorage.setItem(storageKey, response.data.result_artifact_id as string);
            if (linkedRepoId) localStorage.setItem(sourceStorageKey, linkedRepoId);
            localStorage.setItem(runStorageKey, linkedRunId);
          });
        }
        const firstAnalyzable = response.data.output_files.find(
          (item) => item.id && item.stored && item.analyzable,
        );
        if (firstAnalyzable?.id) setSelectedResultFileId(firstAnalyzable.id);
        return undefined;
      })
      .catch((error) => {
        addNotification({
          type: 'error',
          message: getApiErrorMessage(error, '实验运行结果加载失败'),
          duration: 5000,
        });
      });
  }, [addNotification, linkedRepoId, linkedRunId, runStorageKey, sourceStorageKey, storageKey]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;
    const validTypes = ['text/csv', 'application/json', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
    const lowerName = uploadedFile.name.toLowerCase();
    if (!validTypes.includes(uploadedFile.type) && !['.csv', '.json', '.xlsx'].some((ext) => lowerName.endsWith(ext))) {
      addNotification({ type: 'warning', message: '请上传 CSV/JSON/Excel 文件', duration: 3000 });
      return;
    }
    setFile(uploadedFile);
    setSelectedResultFileId('');
  };

  const handleAnalyze = async () => {
    if (isAnalyzing || isJobRunning) return;
    if (linkedRun?.result_artifact_id) {
      addNotification({ type: 'info', message: '该实验运行已生成结果分析，无需重复提交。', duration: 3000 });
      return;
    }
    if (!file && !selectedResultFileId) {
      addNotification({ type: 'warning', message: '请选择运行产物或上传数据文件', duration: 3000 });
      return;
    }
    setIsAnalyzing(true);
    try {
      const response = selectedResultFileId && linkedRunId
        ? await resultAPI.analyzeRunFileAsync(linkedRunId, selectedResultFileId)
        : await resultAPI.analyzeAsync(
            file as File,
            undefined,
            selectedProjectId,
            linkedRepoId,
            linkedRunId,
          );
      trackJob(response.data);
    } catch (error) {
      addNotification({
        type: 'error',
        message: getApiErrorMessage(error, '数据分析失败，请检查文件内容或结果分析智能体配置'),
        duration: 5000,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleArtifactChanged = (detail: import('@/types').ArtifactDetail) => {
    const nextAnalysis = mergeArtifactDetail<ResultAnalysis>(detail);
    setAnalysis(nextAnalysis);
    setDraftAnalysis(null);
    setIsEditing(false);
    localStorage.setItem(storageKey, detail.id);
  };

  const startEditing = () => {
    if (!analysis) return;
    setDraftAnalysis(structuredClone(analysis));
    setIsEditing(true);
  };

  const saveRevision = async () => {
    if (!analysis?.id || !draftAnalysis) return;
    if (!draftAnalysis.interpretation.trim()) {
      addNotification({ type: 'warning', message: '分析结论不能为空', duration: 3000 });
      return;
    }
    setIsSaving(true);
    try {
      const response = await artifactAPI.revise(
        analysis.id,
        {
          charts: draftAnalysis.charts,
          stats: draftAnalysis.stats,
          interpretation: draftAnalysis.interpretation.trim(),
          suggestions: draftAnalysis.suggestions.map((item) => item.trim()).filter(Boolean),
          row_count: draftAnalysis.row_count,
          generation_mode: draftAnalysis.generation_mode,
          experiment_run_id: draftAnalysis.experiment_run_id,
          result_file_id: draftAnalysis.result_file_id,
          code_artifact_id: draftAnalysis.code_artifact_id,
        },
        undefined,
        '人工修订结果分析结论',
      );
      handleArtifactChanged(response.data);
      addNotification({ type: 'success', message: '分析结论已保存为新草稿版本', duration: 3000 });
    } catch (error) {
      addNotification({
        type: 'error',
        message: getApiErrorMessage(error, '分析结论保存失败'),
        duration: 5000,
      });
    } finally {
      setIsSaving(false);
    }
  };

  const barChartOption = useMemo(() => {
    if (!analysis?.stats.length) return null;
    const labels = analysis.stats.map((item) => item.metric);
    const values = analysis.stats.map((item) => item.mean);
    return {
      backgroundColor: 'transparent',
      grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
      xAxis: {
        type: 'category' as const,
        data: labels,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' },
      },
      yAxis: {
        type: 'value' as const,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [{
        data: values,
        type: 'bar' as const,
        itemStyle: {
          color: {
            type: 'linear' as const,
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: '#38bdf8' },
              { offset: 1, color: '#2563eb' },
            ],
          },
          borderRadius: [4, 4, 0, 0],
        },
        barWidth: '40%',
      }],
      tooltip: {
        trigger: 'axis' as const,
        backgroundColor: '#1e293b',
        borderColor: '#334155',
        textStyle: { color: '#f1f5f9' },
      },
    };
  }, [analysis]);

  const lineChartOption = useMemo(() => {
    if (!analysis?.stats.length) return null;
    const labels = analysis.stats.map((item) => item.metric);
    return {
      backgroundColor: 'transparent',
      grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
      xAxis: {
        type: 'category' as const,
        data: labels,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' },
      },
      yAxis: {
        type: 'value' as const,
        axisLine: { lineStyle: { color: '#334155' } },
        axisLabel: { color: '#94a3b8' },
        splitLine: { lineStyle: { color: '#1e293b' } },
      },
      series: [
        {
          name: '最小值',
          data: analysis.stats.map((item) => item.min),
          type: 'line' as const,
          smooth: true,
          lineStyle: { color: '#38bdf8', width: 2 },
          itemStyle: { color: '#38bdf8' },
          areaStyle: {
            color: {
              type: 'linear' as const,
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(56,189,248,0.2)' },
                { offset: 1, color: 'rgba(56,189,248,0)' },
              ],
            },
          },
        },
        {
          name: '均值',
          data: analysis.stats.map((item) => item.mean),
          type: 'line' as const,
          smooth: true,
          lineStyle: { color: '#f59e0b', width: 2 },
          itemStyle: { color: '#f59e0b' },
        },
        {
          name: '最大值',
          data: analysis.stats.map((item) => item.max),
          type: 'line' as const,
          smooth: true,
          lineStyle: { color: '#22c55e', width: 2 },
          itemStyle: { color: '#22c55e' },
        },
      ],
      legend: {
        data: ['最小值', '均值', '最大值'],
        textStyle: { color: '#94a3b8' },
        bottom: 0,
      },
      tooltip: {
        trigger: 'axis' as const,
        backgroundColor: '#1e293b',
        borderColor: '#334155',
        textStyle: { color: '#f1f5f9' },
      },
    };
  }, [analysis]);

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      <h1 className="text-2xl font-bold">结果分析</h1>
      <ProjectContextBar />

      {linkedRunId && (
        <div className="flex items-center gap-2 rounded-lg border border-sci-success/30 bg-sci-success/10 px-4 py-3 text-sm text-sci-ink">
          <FolderKanban size={16} className="text-sci-success" />
          本次分析将关联实验运行 <span className="font-mono text-xs text-sci-accent">{linkedRunId.slice(0, 8)}</span>
        </div>
      )}

      {/* Upload */}
      <div className="sci-card-glow">
        {linkedRunId && (
          <div className="mb-4">
            <label htmlFor="run-result-file" className="mb-2 block text-sm font-medium text-sci-ink">
              使用受控实验产物
            </label>
            <select
              id="run-result-file"
              className="sci-input w-full"
              value={selectedResultFileId}
              disabled={Boolean(linkedRun?.result_artifact_id)}
              onChange={(event) => {
                setSelectedResultFileId(event.target.value);
                if (event.target.value) setFile(null);
              }}
            >
              <option value="">手工上传其他结果文件</option>
              {(linkedRun?.output_files || [])
                .filter((item) => item.id && item.stored && item.analyzable)
                .map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.relative_path || item.name} · {typeof item.size_bytes === 'number' ? `${(item.size_bytes / 1024).toFixed(1)} KB` : '大小未知'}
                  </option>
                ))}
            </select>
            {linkedRun && !linkedRun.output_files.some((item) => item.id && item.stored && item.analyzable) && (
              <p className="mt-2 text-xs text-sci-muted">
                该运行没有已保存的 CSV、JSON 或 XLSX 产物，请在下方手工上传。
              </p>
            )}
            {linkedRun?.result_artifact_id && (
              <p className="mt-2 text-xs text-sci-muted">
                该运行已完成结果分析，下面展示已保存的分析产物。
              </p>
            )}
          </div>
        )}
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-sci-ink mb-2">
              上传实验数据
            </label>
            <input
              type="file"
              accept=".csv,.json,.xlsx"
              onChange={handleFileUpload}
              className="hidden"
              id="data-upload"
            />
            <label
              htmlFor="data-upload"
              className="flex items-center gap-3 p-4 rounded-xl border-2 border-dashed border-sci-border hover:border-sci-accent/50 cursor-pointer transition-colors"
            >
              <FileSpreadsheet size={24} className="text-sci-accent" />
              <div>
                <p className="text-sm font-medium">
                  {file ? file.name : '点击或拖拽上传 CSV / JSON / Excel'}
                </p>
                <p className="text-xs text-sci-muted">
                  {file ? `${(file.size / 1024).toFixed(1)} KB` : '支持 .csv, .json, .xlsx'}
                </p>
              </div>
            </label>
          </div>
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing || isJobRunning || Boolean(linkedRun?.result_artifact_id) || (!file && !selectedResultFileId)}
            className="sci-btn-primary self-end"
          >
            {isAnalyzing || isJobRunning ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                分析中
              </>
            ) : (
              <>
                <BarChart3 size={16} />
                开始分析
              </>
            )}
          </button>
        </div>
        {isJobRunning && (
          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-sci-muted">
            <span>智能体正在后台解释结果，当前进度 {job?.progress ?? 0}%。刷新页面后任务会继续。</span>
            <button type="button" onClick={() => void cancelJob()} className="sci-btn-secondary text-xs">
              取消任务
            </button>
          </div>
        )}
        {job?.status === 'failed' && (
          <button type="button" onClick={() => void retryJob()} className="sci-btn-secondary mt-3">
            重试结果分析
          </button>
        )}
      </div>

      <AgentKnowledgePanel category="result-interpretation" />

      {analysis && (
        <div className="space-y-6">
          <ArtifactReviewToolbar
            artifact={analysis}
            isEditing={isEditing}
            isSaving={isSaving}
            onEdit={startEditing}
            onSave={() => void saveRevision()}
            onCancel={() => {
              setDraftAnalysis(null);
              setIsEditing(false);
            }}
            onArtifactChanged={handleArtifactChanged}
          />

          {/* Charts */}
          <div>
            <h2 className="sci-section-title mb-4">图表分析</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="sci-card">
                <h3 className="text-sm font-medium text-sci-muted mb-4">各数值字段均值</h3>
                {barChartOption ? (
                  <Suspense fallback={(
                    <div className="h-[250px] flex items-center justify-center text-sci-muted text-sm">
                      图表加载中...
                    </div>
                  )}>
                    <ResultChart option={barChartOption} />
                  </Suspense>
                ) : (
                  <div className="h-[250px] flex items-center justify-center text-sci-muted text-sm">
                    图表加载中...
                  </div>
                )}
              </div>
              <div className="sci-card">
                <h3 className="text-sm font-medium text-sci-muted mb-4">各字段范围与均值</h3>
                {lineChartOption ? (
                  <Suspense fallback={(
                    <div className="h-[250px] flex items-center justify-center text-sci-muted text-sm">
                      图表加载中...
                    </div>
                  )}>
                    <ResultChart option={lineChartOption} />
                  </Suspense>
                ) : (
                  <div className="h-[250px] flex items-center justify-center text-sci-muted text-sm">
                    图表加载中...
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Stats */}
          <div>
            <h2 className="sci-section-title mb-4">统计摘要</h2>
            <div className="grid md:grid-cols-3 gap-4">
              {analysis.stats.map((stat) => (
                <div key={stat.metric} className="sci-card">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold">{stat.metric}</h3>
                    {typeof stat.p_value === 'number' && (
                      <span className="text-xs text-sci-muted">p = {stat.p_value}</span>
                    )}
                  </div>
                  <div className="text-3xl font-bold sci-glow-text mb-3">
                    {stat.mean.toFixed(3)}
                  </div>
                  <div className="space-y-1 text-xs text-sci-muted">
                    <div className="flex justify-between">
                      <span>标准差</span>
                      <span>{stat.std.toFixed(3)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>最小值</span>
                      <span>{stat.min.toFixed(3)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>最大值</span>
                      <span>{stat.max.toFixed(3)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>95% CI</span>
                      <span>[{stat.ci95[0].toFixed(3)}, {stat.ci95[1].toFixed(3)}]</span>
                    </div>
                    <div className="flex justify-between">
                      <span>有效样本</span>
                      <span>{stat.count ?? 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>缺失 / 非法</span>
                      <span>{stat.missing_count ?? 0} / {stat.invalid_count ?? 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>区间方法</span>
                      <span>Student-t</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interpretation */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="sci-card">
              <h3 className="sci-section-title mb-3">分析结论</h3>
              {isEditing && draftAnalysis ? (
                <textarea
                  className="sci-input w-full resize-none text-sm leading-relaxed"
                  rows={8}
                  value={draftAnalysis.interpretation}
                  onChange={(event) => setDraftAnalysis({
                    ...draftAnalysis,
                    interpretation: event.target.value,
                  })}
                />
              ) : (
                <p className="text-sm text-sci-muted leading-relaxed">{analysis.interpretation}</p>
              )}
            </div>
            <div className="sci-card">
              <h3 className="sci-section-title mb-3">改进建议</h3>
              {isEditing && draftAnalysis ? (
                <div className="space-y-2">
                  {draftAnalysis.suggestions.map((suggestion, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <input
                        className="sci-input flex-1 text-sm"
                        value={suggestion}
                        onChange={(event) => setDraftAnalysis({
                          ...draftAnalysis,
                          suggestions: draftAnalysis.suggestions.map((item, suggestionIndex) => suggestionIndex === index ? event.target.value : item),
                        })}
                        aria-label={`改进建议 ${index + 1}`}
                      />
                      <button
                        type="button"
                        onClick={() => setDraftAnalysis({
                          ...draftAnalysis,
                          suggestions: draftAnalysis.suggestions.filter((_, suggestionIndex) => suggestionIndex !== index),
                        })}
                        className="p-2 text-sci-muted hover:text-sci-danger"
                        title="删除建议"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => setDraftAnalysis({
                      ...draftAnalysis,
                      suggestions: [...draftAnalysis.suggestions, '新的改进建议'],
                    })}
                    className="sci-btn-secondary"
                  >
                    <Plus size={14} />
                    添加建议
                  </button>
                </div>
              ) : (
                <ul className="space-y-2">
                  {analysis.suggestions.map((suggestion, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm text-sci-muted">
                      <TrendingUp size={14} className="text-sci-success mt-0.5 flex-shrink-0" />
                      {suggestion}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Export */}
          <div className="flex flex-wrap justify-end gap-3 border-t border-sci-border pt-4">
            <button
              onClick={() => addNotification({ type: 'info', message: '导出功能开发中', duration: 3000 })}
              className="sci-btn-secondary"
            >
              <Download size={16} />
              导出图表
            </button>
            <button
              type="button"
              onClick={() => navigate('/projects')}
              className="sci-btn-primary"
            >
              <FolderKanban size={16} />
              查看项目进度
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default ResultAnalyze;
