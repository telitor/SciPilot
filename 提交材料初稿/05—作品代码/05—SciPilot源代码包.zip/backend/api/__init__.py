"""SciPilot HTTP API package."""
